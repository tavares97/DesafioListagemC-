using CsvHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desafioList
{
    class Program
    {
        static void Main(string[] args)
        {
            ReadFiles();
            
            Console.ReadLine();
        }

        public static void ReadFiles()
        {
            //Asks for username and stores it in a checkUser variable
            Console.WriteLine("Enter your username: ");
            string checkUser = Console.ReadLine();
            //Asks for password and stores it in a checkPass variable
            Console.WriteLine("Enter your password: ");
            string checkPass = Console.ReadLine();

            //Reads the file at the specified path and stores the content in a var, and stores it in a List string by line
            var clients = File.ReadAllLines(@"C:\Users\z00436bz\Desktop\Estagio\DOTNET\desafioList\desafioList\Clients\clients.csv");
            List<string> ClientsList = new List<string>();
            foreach (var line in clients)
            {
                string[] words = line.Split(';');
                ClientsList.Add(line);

            }
            //Reads every line and stores each word in a variable in a new list 
            List<Classes.Clients> ListClients = new List<Classes.Clients>();
            foreach (var item in ClientsList)
            {
                var x = item.Split(';');
                string id = x[0].ToString();
                string name = x[1].ToString();
                string address = x[2].ToString();
                string postalCode = x[3].ToString();
                string country = x[4].ToString();
                string fiscalNumber = x[5].ToString();
                ListClients.Add(new Classes.Clients(id, name, address, postalCode, country, fiscalNumber));
            }

            var users = File.ReadAllLines(@"C:\Users\z00436bz\Desktop\Estagio\DOTNET\desafioList\desafioList\Clients\users.csv");
            List<string> UsersList = new List<string>();
            foreach (var line in users)
            {
                string[] words = line.Split(';');
                UsersList.Add(line);

            }
            List<Classes.Users> ListUsers = new List<Classes.Users>();
            foreach (var item in UsersList)
            {
                var x = item.Split(';');
                string id = x[0].ToString();
                string name = x[1].ToString();
                string password = x[2].ToString();
                string email = x[3].ToString();
                string role = x[4].ToString();

                ListUsers.Add(new Classes.Users(id, name, password, email, role));
            }

            var roles = File.ReadAllLines(@"C:\Users\z00436bz\Desktop\Estagio\DOTNET\desafioList\desafioList\Clients\roles.csv");
            List<string> RolesList = new List<string>();
            foreach (var line in roles)
            {
                string[] words = line.Split(';');
                RolesList.Add(line);

            }
            List<Classes.Roles> ListRoles = new List<Classes.Roles>();
            foreach (var item in RolesList)
            {
                var x = item.Split(';');
                string id = x[0].ToString();
                string role = x[1].ToString();

                ListRoles.Add(new Classes.Roles(id, role));
            }

            string user1 = ListUsers.ElementAt(0).Name;
            string pass1 = ListUsers.ElementAt(0).Pass;
            string checkRole1 = ListUsers.ElementAt(0).Role;
            string role1 = ListRoles.ElementAt(0).ID;

            string user2 = ListUsers.ElementAt(1).Name;
            string pass2 = ListUsers.ElementAt(1).Pass;
            string checkRole2 = ListUsers.ElementAt(1).Role;
            string role2 = ListRoles.ElementAt(1).ID;


            if(user1 == checkUser && pass1 == checkPass && role1 == checkRole1)
            {
                ListClients.ForEach(item => Console.WriteLine($"ID: {item.ID} \nName: {item.Name} \nAddress: {item.Address} \nPostal Code: {item.PostalCode} \nFiscal Number: {item.FiscalNumber}"));
            }
            if(user2 == checkUser && pass2 == checkPass && role2 == checkRole2)
            {
                Console.WriteLine("Sorry you dont have permission to see this content");
            }
            else
            {
                Console.WriteLine("Username Or Password may be incorrect");

            }
        }
    }
}
