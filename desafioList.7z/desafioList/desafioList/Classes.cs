﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desafioList
{
    class Classes
    {
        public class Clients
        {
            public string ID { get; set; }
            public string Name { get; set; }
            public string Address { get; set; }
            public string PostalCode { get; set; }
            public string Country { get; set; }
            public string FiscalNumber { get; set; }

            public Clients(string id, string name, string address, string postalCode, string country, string fiscalNumber)
            {
                ID = id;
                Name = name;
                Address = address;
                PostalCode = postalCode;
                Country = country;
                FiscalNumber = fiscalNumber;
            }

        }

        public class Users
        {

            public string ID { get; set; }
            public string Name { get; set; }
            public string Pass { get; set; }
            public string Email { get; set; }
            public string Role { get; set; }

            public Users(string id, string name, string pass, string email, string role)
            {
                ID = id;
                Name = name;
                Pass = pass;
                Email = email;
                Role = role;
            }
        }

        public class Roles
        {
            public string ID { get; set; }
            public string Role { get; set; }

            public Roles(string id, string role)
            {
                ID = id;
                Role = role;
            }
        }
    }
}
